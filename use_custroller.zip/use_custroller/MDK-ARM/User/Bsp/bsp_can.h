#ifndef BSP_CAN_H
#define BSP_CAN_H

#include "stm32f4xx_hal.h"

void can_filter_init(void);

#endif
