#ifndef DR16_RECEIVER_H_
#define DR16_RECEIVER_H_

#include "main.h"
#include "stm32f4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>


#include "stm32f4xx_hal_def.h"

#define DR16_DBUS_PACKSIZE 		18u		//���ջ�����С

#define DR16_ROCKER_MAXVALUE 		660.0f		//ң��ҡ�����ֵ

//���������¶�Ӧֵ
#define DR16_SWITCH_UP			1
#define DR16_SWITCH_MID			3
#define DR16_SWITCH_DOWN		2

#define MOUSEKEY_NONE 	0x00
#define MOUSEKEY_LEFT 	0x01
#define MOUSEKEY_RIGHT 	0x02

/*-------���̼�ֵ Begin------*/
#define KEYBOARD_PRESSED_NONE 	0x0000

#define KEYBOARD_PRESSED_W 		0x0001
#define KEYBOARD_PRESSED_S 		0x0002
#define KEYBOARD_PRESSED_A 		0x0004
#define KEYBOARD_PRESSED_D 		0x0008
#define KEYBOARD_PRESSED_SHIFT 	0x0010
#define KEYBOARD_PRESSED_CTRL 	0x0020
#define KEYBOARD_PRESSED_Q  	0x0040
#define KEYBOARD_PRESSED_E 		0x0080

#define KEYBOARD_PRESSED_R		0x0100
#define KEYBOARD_PRESSED_F		0x0200
#define KEYBOARD_PRESSED_G		0x0400
#define KEYBOARD_PRESSED_Z		0x0800
#define KEYBOARD_PRESSED_X		0x1000
#define KEYBOARD_PRESSED_C		0x2000
#define KEYBOARD_PRESSED_V		0x4000
#define KEYBOARD_PRESSED_B		0x8000
/*-------���̼�ֵ End------*/

#define KEY_FULL_MATCH			0x01
#define KEY_HAVE_MATCH			0x00


#include "stm32f4xx_hal_def.h"

#pragma anon_unions

typedef struct {
	float x;
	float y;
	float radian;
	float degrees;
	float distance;
}rocker_t;   //ҡ��

typedef struct {
		float w;
		float x;
		float y;
		float z;
}quaternion_t;

typedef struct {
		float x;
		float y;
		float z;
}vector_t;

typedef struct {
		int16_t x;
		int16_t y;
		int16_t z; 
}vector16_t;

typedef struct {
	float roll;
	float pitch;
	float yaw;
}eular_t;






typedef struct{
  union{
    uint8_t data;
    struct{
      uint8_t KeyStatus:1;           
      uint8_t lastKeyStatus:1;
      uint8_t keyPressedJump:1;
      uint8_t keyReleaseJump:1;
      uint8_t longPressed:1;
    };
  }flag;
	uint16_t timeCounter;
}key_t;

typedef struct{
  uint16_t KeyStatus;
  uint16_t lastKeyStatus;
  uint16_t keyPressedJump;
  uint16_t keyReleaseJump;
  uint16_t longPressed;
	uint16_t timeCounter[16];
}keyBoard_t;


typedef  struct  
{
	
struct{
  int16_t ch0;
  int16_t ch1;
  int16_t ch2;
  int16_t ch3;
  int16_t roll;
  uint8_t sw1;
  uint8_t sw2;
}rc;
	
	struct{
		int16_t x;
		int16_t y;
		int16_t z;
	
		uint8_t keyLeft;
		uint8_t keyRight;
		
	}mouse;
	
	union {
		uint16_t key_code;
		struct{
			bool press_W:1;
			bool press_S:1;
			bool press_A:1;
			bool press_D:1;
			bool press_Shift:1;
			bool press_Ctrl:1;
			bool press_Q:1;
			bool press_E:1;
			
			bool press_R:1;
			bool press_F:1;
			bool press_G:1;
			bool press_Z:1;
			bool press_X:1;
			bool press_C:1;
			bool press_V:1;
			bool press_B:1;
		};
	}keyBoard;
	
	uint16_t InfoUpdateFrame;	//֡��
	int offLineFlag;		//�豸���߱�־
	
} DR16_DBUS_DATA_t;

#define DR16_DBUS_DATA_t_Init   \
{                 \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
		0,            \
}

#define DR16_DBUS_PACKSIZE 		18u		//���ջ�����С

#define DBUS_MAX_LEN     (50)
#define DBUS_BUFLEN      (18)
#define DBUS_HUART       huart1



extern keyBoard_t dr16_keyBorad;
extern key_t dr16_mouseKeyLeft;
extern key_t dr16_mouseKeyRight;

extern uint8_t   dbus_buf[DBUS_BUFLEN];
extern DR16_DBUS_DATA_t DR16_data;


void DR16_mouseProcess(uint8_t newKeyStatus, key_t *key);
void DR16_keyBoardProcess(uint16_t newKeyStatus, keyBoard_t *keyBoard);
void DR16_KeyProcessing(void);


void rc_callback_handler(uint8_t *buff);
void uart_receive_handler(UART_HandleTypeDef *huart);




#endif /* DR16_RECEIVER_H_ */
