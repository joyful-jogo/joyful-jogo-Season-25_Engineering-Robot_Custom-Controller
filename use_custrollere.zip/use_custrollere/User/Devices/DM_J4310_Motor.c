/**
  ******************************************************************************
  * @file    DM_J4310_Motor.c
  * @author  BLOCK
  * @version V1.0
  * @date    
  * @brief   ����J4310-2EC��������ӿ�
  ******************************************************************************
  */
#include "DM_J4310_Motor.h"
#include "can_receive.h"
#include "cmsis_os.h"
#include <stdint.h>
#include "LK_MG4005_Motor.h"


DM_J8009_t DM_J8009[2];

/*
 * @brief: CAN Receive Message.
 * @param: "RxData[]" will store the message which has been received, which length must between 0 and 8.
 * @retval: receive status.
 */
void DM_J8009_getInfo(DM_J8009_t *ptr, Can_Export_Data_t RxMessage)
{
	ptr->p_int=(RxMessage.CAN_RxMessage[1]<<8) | RxMessage.CAN_RxMessage[2];
	ptr->v_int=(RxMessage.CAN_RxMessage[3]<<4) | (RxMessage.CAN_RxMessage[4]>>4);
	ptr->t_int=((RxMessage.CAN_RxMessage[4]&0xF)<<8) | RxMessage.CAN_RxMessage[5];
	ptr->position = uint_to_float(ptr->p_int, P_MIN, P_MAX, 16); // (-12.5,12.5)
	ptr->velocity = uint_to_float(ptr->v_int, V_MIN, V_MAX, 12); // (-45.0,45.0)
	ptr->torque   = uint_to_float(ptr->t_int, T_MIN, T_MAX, 12); // (-18.0,18.0)
	
	ptr->InfoUpdateFrame++;
	ptr->InfoUpdateFlag = 1;		
}


/**
 * @brief  ���ø������ݵȱ���ת��������
 * @param  x_int     	Ҫת�����޷�������
 * @param  x_min      Ŀ�긡��������Сֵ
 * @param  x_max    	Ŀ�긡���������ֵ
 * @param  bits      	�޷���������λ��
 */
float uint_to_float(int x_int, float x_min, float x_max, int bits){
/// converts unsigned int to float, given range and number of bits ///
 float span = x_max - x_min;
 float offset = x_min;
 return ((float)x_int)*span/((float)((1<<bits)-1)) + offset;
}

/**
 * @brief  ��������ת��Ϊ�޷�������
 * @param  x     			Ҫת���ĸ�����
 * @param  x_min      ����������Сֵ
 * @param  x_max    	�����������ֵ
 * @param  bits      	�޷���������λ��
 */

int float_to_uint(float x, float x_min, float x_max, int bits){
 /// Converts a float to an unsigned int, given range and number of bits///
 float span = x_max - x_min;
 float offset = x_min;
 return (int) ((x-offset)*((float)((1<<bits)-1))/span);
}



/**
 * @brief  MITģʽ���¿���֡
 * @param  hcan   CAN�ľ��
 * @param  ID     ����֡��ID
 * @param  _pos   λ�ø���
 * @param  _vel   �ٶȸ���
 * @param  _KP    λ�ñ���ϵ��
 * @param  _KD    λ��΢��ϵ��
 * @param  _torq  ת�ظ���ֵ
 */
void MIT_CtrlMotor(CAN_HandleTypeDef* hcan,uint16_t id, float _pos, float _vel,float _KP, float _KD, float _torq)
 { 
	uint8_t TXdata[8];
	static CAN_TxHeaderTypeDef   Tx_Header;
	uint16_t pos_tmp,vel_tmp,kp_tmp,kd_tmp,tor_tmp;
	pos_tmp = float_to_uint(_pos, P_MIN, P_MAX, 16);
	vel_tmp = float_to_uint(_vel, V_MIN, V_MAX, 12);
	kp_tmp = float_to_uint(_KP, KP_MIN, KP_MAX, 12);
	kd_tmp = float_to_uint(_KD, KD_MIN, KD_MAX, 12);
	tor_tmp = float_to_uint(_torq, T_MIN, T_MAX, 12);

	Tx_Header.StdId=id;
	Tx_Header.IDE=CAN_ID_STD;
	Tx_Header.RTR=CAN_RTR_DATA;
	Tx_Header.DLC=0x08;
	
	TXdata[0] = (pos_tmp >> 8);
	TXdata[1] = pos_tmp;
	TXdata[2] = (vel_tmp >> 4);
	TXdata[3] = ((vel_tmp&0xF)<<4)|(kp_tmp>>8);
	TXdata[4] = kp_tmp;
	TXdata[5] = (kd_tmp >> 4);
	TXdata[6] = ((kd_tmp&0xF)<<4)|(tor_tmp>>8);
	TXdata[7] = tor_tmp;
	 
	 //Ѱ�����䷢������
	if(HAL_CAN_AddTxMessage(hcan, &Tx_Header, TXdata, (uint32_t*)CAN_TX_MAILBOX0) != HAL_OK) 
	{
		if(HAL_CAN_AddTxMessage(hcan, &Tx_Header, TXdata, (uint32_t*)CAN_TX_MAILBOX1) != HAL_OK)
		{
			HAL_CAN_AddTxMessage(hcan, &Tx_Header, TXdata, (uint32_t*)CAN_TX_MAILBOX2);
    }
   }
 }

//void save_motor_zero(CAN_HandleTypeDef,uint16_t motor_id)
//{
//	uint8_t data[0];
//	uint16_t id = motor_id;
//	
//	data[0] = 0xFF;
//	data[1] = 0xFF;
//	data[2] = 0xFF;
//	data[3] = 0xFF;	
//	data[4] = 0xFF;
//	data[5] = 0xFF;
//	data[6] = 0xFF;
//	data[7] = 0xFE;
//	
//	CANx_SendData(
//}


 
