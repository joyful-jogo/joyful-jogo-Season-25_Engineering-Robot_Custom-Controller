#ifndef MANUALMODE_TASK_H_
#define MANUALMODE_TASK_H_

void InitializeModules(void);
void vTaskManual( void const * argument);
#endif
