#ifndef __DEVICESMONITOR_TASKS_H
#define __DEVICESMONITOR_TASKS_H

#include "gpio.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"


typedef struct
{
 uint32_t WorldTime;               //����ʱ��
 uint32_t Previous_WorldTime;     //��һ������ʱ��
}WorldTime_t;

extern WorldTime_t WorldTime;

uint8_t FPS_Calculate(uint16_t deltaTime);
void Get_FPS(WorldTime_t *time, uint8_t *FPS);

void vTaskDeviceMonitor(void const * argument);
	 
 
#endif
