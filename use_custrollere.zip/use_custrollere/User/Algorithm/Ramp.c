/**
  ******************************************************************************
  * @file    Ramp.c
  * @author  Hare
  * @version V1.0
  * @date    
  * @brief   б�»��庯���ӿ�
  ******************************************************************************
  */
  
  
#include "Ramp.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void ramp_init(ramp_t *ramp, int32_t scale)
{
  ramp->count = 0;
  ramp->scale = scale;
}

float ramp_calc(ramp_t *ramp)
{
  if (ramp->scale <= 0)
    return 0;
  
  if (ramp->count++ >= ramp->scale)
    ramp->count = ramp->scale;
  
  ramp->out = ramp->count / ((float)ramp->scale);
  return ramp->out;
}
/**
 * @brief   ����������б�º���
 * @param   None
 * @retval  None
 */
void Gyro_Drv_Slow(float *rec , float target ,float curret ,float slow_Inc)
{
//	 static float temp;
    if(fabs(curret - target) < slow_Inc)
    {
        *rec = target;
    }
    else 
    {
        if(curret > target)
				{
					*rec = curret-slow_Inc;
				}
        else if(curret < target)
				{
					*rec = curret+slow_Inc;
				}
    }
}
