#ifndef __WRIST_SWING_H
#define __WRIST_SWING_H


#include "stm32f4xx_hal.h"
#include "PID.h"
#include "LK_MG4005_Motor.h"



#define MG4005_MaxOutput 360000000
//#define MG4005_MaxOutput 360000
#define M2006_LimitOutput 8000

#define Init_Pit_Limit 888//��ʼ����޷�
#define Left_Pit  0
#define Right_Pit 1
#define middle_Pit 2

typedef enum{
  WRIST_MODE_OFF = 0,
  WRIST_MODE_POSITION = 1,
  WRIST_MODE_MANUAL = 2,
	WRIST_MODE_LOCK = 3,
	WRIST_MODE_VISION = 4,	/*�Ӿ�����x,yȷ����ʯ���ĵ�ģʽ*/
}WristMode_e;

typedef struct {
LK_MG_t LK_MG[3];
	
float input_angleCule_L;
float	input_angleCule_R;
float input_angleCule_3;   //ÿʱ�̵����Ŀ��Ƕ�
	
	
float real_angleCule_L,real_angleCule_R;    //ÿʱ�̵���ĵ�ǰ�Ƕ�
}LK_Motor_t;

extern LK_Motor_t LK_M;


float encoder_to_angle(uint16_t encoder_value);
void	Wrist_Motor_control(void);
void Wrist_resetAngle(void);
void Wrist_Init(void);
void Wrist_Processing(void);
void Wrist_limiting(void);

//void Pump_Switch(void);

#define LK_WristL_OPIDInit   \
    {                      \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        MG4005_MaxOutput,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }


#define LK_WristL_IPIDInit   \
    {                      \
        3.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        MG4005_MaxOutput,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
		
		
#define LK_WristR_OPIDInit   \
    {                      \
        3.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        MG4005_MaxOutput,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }


#define LK_WristR_IPIDInit   \
    {                      \
        3.4f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
#endif
