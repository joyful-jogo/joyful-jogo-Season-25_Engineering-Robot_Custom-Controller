#ifndef __RAMP_H
#define __RAMP_H

//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>
//#include <stdbool.h>
////#include <arm_math.h>

#include "stm32f4xx.h"


#define RAMP_GEN_DAFAULT \
{ \
              .count = 0, \
              .scale = 0, \
              .out = 0, \
            } \

typedef struct{
  int32_t count;
  int32_t scale;
  float   out;
}ramp_t;						
						
						
void  ramp_init(ramp_t *ramp, int32_t scale);
float ramp_calc(ramp_t *ramp);
void Gyro_Drv_Slow(float *rec , float target ,float curret ,float slow_Inc);

#endif /* __RAMP_H */

