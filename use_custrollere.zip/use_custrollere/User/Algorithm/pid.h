#ifndef _PID_H
#define _PID_H

#include "main.h"

#define LIMIT_MIN_MAX(x,min,max) (x) = (((x)<=(min))?(min):(((x)>=(max))?(max):(x)))

#define VAL_LIMIT(val, min, max)	\
do {															\
if((val) <= (min))								\
{																	\
  (val) = (min);									\
}																	\
else if((val) >= (max))						\
{																	\
  (val) = (max);									\
}																	\
} while(0)												\


typedef struct _pid_struct_t {
    float kp;
    float ki;
    float kd;
    float i_max;
    float out_max;

    float tar;
    float now;
    float err[2];

    float p_out;
    float i_out;
    float d_out;
    float output;

    float (*pid_calc)(struct _pid_struct_t *pid_t, float target, float measured);
} pid_struct_t;

float pid_calc(pid_struct_t *pid, float tar, float now);



typedef struct _pid_struct_t_GM6020 {
    float kp;
    float ki;
    float kd;
    float i_max;
    float out_max;

    float tar;
    float now;
    float err[2];

    float p_out;
    float i_out;
    float d_out;
    float output;

    float (*pid_calc_M6020)(struct _pid_struct_t_GM6020 *pid_t, float target, float measured);
} pid_struct_t_GM6020;

float pid_calc_M6020(pid_struct_t *pid, float tar, float now);


typedef struct
{
	pid_struct_t outer;
	pid_struct_t inner;
	float output;
}pid_Cascade_t;

void pid_init(pid_struct_t *pid,
              float kp,
              float ki,
              float kd,
              float i_max,
              float out_max);
												
							
void abs_limit(float *a, float ABS_MAX);
							
float pid_calc_cloud(pid_struct_t *pid, float tar, float now);
float pid_calc_M6020(pid_struct_t *pid, float tar, float now);
float pid_CascadeCalc_lifting(pid_Cascade_t *pid,float angleTar,float angleNow,float speedNow);
float pid_CascadeCalc_cloud(pid_Cascade_t *pid,float angleTar,float angleNow,float speedNow);

							
							
extern pid_struct_t motor_pid_chassis[4];							

#endif						

