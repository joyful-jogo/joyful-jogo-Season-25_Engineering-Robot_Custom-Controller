#ifndef __DEVICESMONITOR_H
#define __DEVICESMONITOR_H



#include "DR16_Receiver.h"


/*������֡��*/
typedef struct {
    uint8_t ManualMode;    // �ֶ�ģʽ����� FPS
} RobotFPS_t;

extern RobotFPS_t RobotFPS;
 
void DevicesMonitor_update(void);
//void Task_WorldTime(void);
//void vTaskWorldTime(void const * argument);
//uint8_t FPS_Calculate(uint16_t deltaTime);

#endif /* __DEVICESMONITOR_H */
