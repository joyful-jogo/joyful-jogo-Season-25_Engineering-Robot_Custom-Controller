#include "Chassis_control.h"
#include "Chassis_motor.h"
#include "pid.h"
#include "DR16_Receiver.h"

pid_struct_t M3508_LF_OPID = M3508_LF_OPIDInit;
pid_struct_t M3508_RF_OPID = M3508_RF_OPIDInit;
pid_struct_t M3508_LB_OPID = M3508_LB_OPIDInit;
pid_struct_t M3508_RB_OPID = M3508_RB_OPIDInit;

int16_t speed_buff[4];

/**
  * @brief  ȡ�����ľ���ֵ
  */
static float custom_abs(float num)
{
		int temp;
		if(num<0) temp=-num;
		else temp=num;
		return temp;
}
/**
  * @brief  ���ֽ���
  */
static void MecanumCalculate(float X_Move,float Y_Move,float Yaw ,int16_t *Speed)
{
		float target_speed[4];
    float MaxSpeed = 0.0f;
    float Param = 1.0f;
 
	  target_speed[0] = 	X_Move - Y_Move + Yaw;
		target_speed[1] =    X_Move + Y_Move + Yaw;
		target_speed[2] =   -(Yaw - X_Move + Y_Move)  ;
		target_speed[3]=    -(Yaw -X_Move - Y_Move) ;		

    for(uint8_t i = 0 ; i<4 ; i ++)
    {
        if(custom_abs(target_speed[i]) > MaxSpeed)
        {
            MaxSpeed = custom_abs(target_speed[i]);
        }
    }

    if (MaxSpeed > 10000)
    {
        Param = (float)10000 / MaxSpeed;
    }

    Speed[0] = target_speed[0] * Param;
    Speed[1] = target_speed[1] * Param;
    Speed[2] = target_speed[2] * Param;
    Speed[3] = target_speed[3] * Param;
}


void Chassis_Processing(void)
{
	if (DR16_data.rc.sw1 == 2 && DR16_data.rc.sw2 == 2)
	{
		set_M3508_chassis_voltage(0,
		                          0,
		                          0,
		                          0);
	}
	else
	{
		set_M3508_chassis_voltage(M3508s_chassis[0].outCurrent,
		                          M3508s_chassis[1].outCurrent,
		                          M3508s_chassis[2].outCurrent,
		                          M3508s_chassis[3].outCurrent);
	}
	
	
	if (DR16_data.rc.sw1 == 3 && DR16_data.rc.sw2 == 3)
	{
		MecanumCalculate(DR16_data.rc.ch2,DR16_data.rc.ch3,DR16_data.rc.ch0,speed_buff);
		
  }
	
M3508_LF_OPID.pid_calc(&M3508_LF_OPID,speed_buff[0] *10,M3508s_chassis[0].realSpeed);
M3508_RF_OPID.pid_calc(&M3508_RF_OPID,speed_buff[1] *10,M3508s_chassis[1].realSpeed);
M3508_LB_OPID.pid_calc(&M3508_LB_OPID,speed_buff[2] *10,M3508s_chassis[2].realSpeed);
M3508_RB_OPID.pid_calc(&M3508_RB_OPID,speed_buff[3] *10,M3508s_chassis[3].realSpeed);
		
M3508s_chassis[0].outCurrent = M3508_LF_OPID.output;
M3508s_chassis[1].outCurrent = M3508_RF_OPID.output;
M3508s_chassis[2].outCurrent = M3508_LB_OPID.output;
M3508s_chassis[3].outCurrent = M3508_RB_OPID.output;	
}

