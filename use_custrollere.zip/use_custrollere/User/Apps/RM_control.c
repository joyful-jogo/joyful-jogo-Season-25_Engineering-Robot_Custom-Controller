#include "RM_control.h"
#include "RM_Motor.h"
#include "DR16_Receiver.h"
#include "Filter.h"
#include "Ramp.h"

GM6020_Motor_t GM6020_M;

pid_struct_t_GM6020 GM6020_OPID = GM6020_OPIDInit;
pid_struct_t        GM6020_IPID = GM6020_IPIDInit;

void DJI_Motor_control(void)
{
	set_DJI_voltage_Can1(GM6020_M.input_M6020_voltage,
								 0,
								 M2006_M.DJI_M2006[0].outCurrent,
								 M2006_M.DJI_M2006[1].outCurrent
								 );

//	set_DJI_voltage_Can1(GM6020_M.input_M6020_voltage,
//								 0,
//								 0,
//								 0
//								 );
}

/* ��ת�� 6020 part*/
void GM6020_Init(void)
{
	GM6020_M.DJI_GM6020.targetAngle = GM6020_M.DJI_GM6020.realAngle;
}

void GM6020_Processing(void)
{
	if (DR16_data.rc.sw1 == 2 && DR16_data.rc.sw2 == 2)
	{
//	GM6020_M.DJI_GM6020.targetAngle = GM6020_M.DJI_GM6020.realAngle;
		GM6020_M.input_M6020_voltage = 0;
	}
	else
	{
		GM6020_M.DJI_GM6020.targetAngle = GM6020_M.DJI_GM6020.realAngle;
	}	
	
	
		if (DR16_data.rc.sw1 == 1 && DR16_data.rc.sw2 == 1)
	{
		GM6020_M.DJI_GM6020.targetAngle += DR16_data.rc.ch2 *0.8;
		VAL_LIMIT(GM6020_M.DJI_GM6020.targetAngle,0,8192);
	
	
GM6020_OPID.pid_calc_M6020(&GM6020_OPID ,GM6020_M.DJI_GM6020.targetAngle,GM6020_M.DJI_GM6020.realAngle);
GM6020_IPID.pid_calc(&GM6020_IPID ,GM6020_OPID.output ,GM6020_M.DJI_GM6020.realSpeed);
	

GM6020_M.input_M6020_voltage = GM6020_IPID.output;

	DJI_Motor_control();
	}
	
}



/* ��ڶ� 2006 part*/



#define Wrist_FULL_TRAVEL 330000
#define Wrist_SPEED_NORMAL 1500

M2006_Motor_t M2006_M;


pid_struct_t M2006R_OPID = WristR_OPIDInit;
pid_struct_t M2006R_IPID = WristR_IPIDInit;

pid_struct_t M2006L_OPID = WristL_OPIDInit;
pid_struct_t M2006L_IPID = WristL_IPIDInit;




/**
  * @brief  ���ü�ȡ�ĽǶȣ����ú��ȡ���ջز�����Ϊ��ʼλ��
  * @param  None
  * @retval None
  */ 
void M2006_resetAngle(void)
{
	M2006_M.WristInit = 0;
	M2006_M.timeCounter = 0;    /* �Ƕȸ�λ�ü����� */
	uint16_t count = 0;         /* �豸�����ü����� */
	//��λ���۵��
  while (M2006_M.WristInit == 0)
	{
		set_DJI_voltage_Can1(0,0,1000,-1000);
//		osDelay(10);
		if (M2006_M.DJI_M2006[1].InfoUpdateFlag)
		{
			M2006_M.DJI_M2006[1].InfoUpdateFlag = 0;
			count = 0;
			/* �ȴ�����е��������ٶȽ�С˵���Ѹ�λ */
			if (abs(M2006_M.DJI_M2006[0].realSpeed) < 2 && 
				  abs(M2006_M.DJI_M2006[0].realSpeed) < 2)
			{
				M2006_M.timeCounter++;
				/* �ٶ�Ϊ����Ϊ0һ��ʱ�䣬��λ��� */
				if (M2006_M.timeCounter > 25)
				{
					M2006_M.timeCounter = 0;
					M2006_M.WristInit = 1;
				}
			}
				else 
				{
					M2006_M.timeCounter = 0;
				}
		}
		else
		{
			count++;
			/* �豸���� */
			if (count > 200)
			{
				/* ���������Ĭ�ϽǶ���3800���� */
				M2006_M.timeCounter = 0;
				return;
			}
		}
	}
	/* ����ͷ� */
	set_DJI_voltage_Can1(0, 0, 0, 0);
//	osDelay(25);
	
}

/**
  * @brief  ̧����ʼ������
  * @param
  * @retval None
  */
void M2006_Init(void)
{
  M2006_resetAngle();
//	//�����Ƕ�Ϊ��ǰ�ۻ��Ƕ�
	M2006_M.DJI_M2006[0].targetAngle = M2006_M.DJI_M2006[0].totalAngle;
	M2006_M.DJI_M2006[1].targetAngle = M2006_M.DJI_M2006[1].totalAngle;
//	Wrist.mode = Wrist_MODE_LOCK;		   //����ģʽ#
	M2006_M.speedLimit = Wrist_SPEED_NORMAL; //̧���ٶ�����
//	Wrist.targetPos_Z = 300; //�趨�Ӿ�Y��Ŀ��ֵ
	M2006_M.minPos_L = M2006_M.DJI_M2006[0].totalAngle;
	M2006_M.maxPos_L = M2006_M.minPos_L - Wrist_FULL_TRAVEL;		 /*�����λ*/	
	M2006_M.minPos_R = M2006_M.DJI_M2006[1].totalAngle;
	M2006_M.maxPos_R = M2006_M.minPos_R + Wrist_FULL_TRAVEL;		 /*�����λ*/
	
	M2006_M.pitchL = M2006_M.minPos_L;
	M2006_M.pitchR = M2006_M.minPos_R;
//	/* ���PID */
	M2006R_OPID.pid_calc(&M2006R_OPID, M2006_M.DJI_M2006[1].targetAngle, M2006_M.DJI_M2006[1].totalAngle);
	M2006R_IPID.pid_calc(&M2006R_IPID, M2006R_OPID.output,M2006_M.DJI_M2006[1].realSpeed);
	
	M2006L_OPID.pid_calc(&M2006L_OPID, M2006_M.DJI_M2006[0].targetAngle, M2006_M.DJI_M2006[0].totalAngle);
  M2006L_IPID.pid_calc(&M2006L_IPID, M2006L_OPID.output,M2006_M.DJI_M2006[0].realSpeed);
}



uint8_t  key_flag;
void M2006_Processing(void)
{
	if (DR16_data.rc.sw1 == 1 && DR16_data.rc.sw2 == 1)
	{
		
		M2006_M.pitchL += DR16_data.rc.ch1*1;
		M2006_M.pitchR -= DR16_data.rc.ch1*1;
		M2006_M.little_roll += DR16_data.rc.ch0*2;
		
	}
	if (DR16_data.rc.sw1 == 2 && DR16_data.rc.sw2 == 2)
	{
		M2006_M.DJI_M2006[0].outCurrent =	M2006_M.DJI_M2006[1].outCurrent =	0;
	set_DJI_voltage_Can1(GM6020_M.input_M6020_voltage,
								 0,
								 0,
								 0
								 );
			return;
	}
	else
	{
		//����		
M2006_M.DJI_M2006[0].targetAngle = M2006_M.pitchL + M2006_M.little_roll;
M2006_M.DJI_M2006[1].targetAngle = M2006_M.pitchR + M2006_M.little_roll;	
	}
	
	//��λ
		if(M2006_M.pitchL < M2006_M.maxPos_L || M2006_M.pitchR > M2006_M.maxPos_R)//Ŀ��Ƕ�����߽Ƕ����(ע������) 
		{
			M2006_M.pitchL = M2006_M.maxPos_L ;
			M2006_M.pitchR = M2006_M.maxPos_R ;//Lifting.M3508s[1].targetAngle
		}
	
	//����λ�����½�
		if(M2006_M.pitchL > M2006_M.minPos_L || M2006_M.pitchR < M2006_M.minPos_R) //Ŀ��Ƕ�����߽Ƕ����(ע������) 
		{
			M2006_M.pitchL = M2006_M.minPos_L;
			M2006_M.pitchR = M2006_M.minPos_R;
		}
	
	/* ���PID */
		M2006R_OPID.pid_calc(&M2006R_OPID, M2006_M.DJI_M2006[0].targetAngle, M2006_M.DJI_M2006[0].totalAngle);
		//�ٶ�����
		VAL_LIMIT(M2006R_OPID.output, -1500, 1500);
		
		M2006R_IPID.pid_calc(&M2006R_IPID, M2006R_OPID.output,M2006_M.DJI_M2006[0].realSpeed);
			
		M2006L_OPID.pid_calc(&M2006L_OPID, M2006_M.DJI_M2006[1].targetAngle, M2006_M.DJI_M2006[1].totalAngle);
		//�ٶ�����
		VAL_LIMIT(M2006L_OPID.output, -1500, 1500);
		M2006L_IPID.pid_calc(&M2006L_IPID, M2006L_OPID.output,M2006_M.DJI_M2006[1].realSpeed);

	M2006_M.DJI_M2006[0].outCurrent =	M2006R_IPID.output;
	M2006_M.DJI_M2006[1].outCurrent =	M2006L_IPID.output;
	
	
DJI_Motor_control();

}




