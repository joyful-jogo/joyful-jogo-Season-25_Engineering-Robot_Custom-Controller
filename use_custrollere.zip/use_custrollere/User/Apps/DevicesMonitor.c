/**
  ******************************************************************************
  * @file    DevicesMonitor.c
  * @author  HTH
  * @version V1.0
  * @date    
  * @brief  ֡�ʼ��
	******************************************************************************
  */

#include "DevicesMonitor.h"
#include "LK_MG4005_Motor.h"

RobotFPS_t RobotFPS;





/**
  * @brief  ֡�ʼ�⺯��
  * @param  None
  * @retval None
  */
uint8_t counter = 0;
void DevicesMonitor_update(void)
{
    // ֡�ʼ�⺯��
    if(DR16_data.InfoUpdateFrame < 5){
        DR16_data.offLineFlag = 1;
    }
    else{
        DR16_data.offLineFlag = 0;
    }
    DR16_data.InfoUpdateFrame = 0;  
		
	for (int i=0;i <=4;i++)
	{
	 if(LK_MG[i].InfoUpdateFrame < 5){
        LK_MG[i].OffLineFlag = 1;
    }
    else{
        LK_MG[i].OffLineFlag = 0;
    }
    LK_MG[i].OffLineFlag = 0;  
	}
		
}



