#ifndef CAN_RECEIVE_H
#define CAN_RECEIVE_H

#include "can.h"

#include "LK_MG4005_Motor.h"
#include "DM_J4310_Motor.h"

typedef struct
{
    CAN_RxHeaderTypeDef CAN_RxHeader;
    uint8_t CAN_RxMessage[8];
} Can_Export_Data_t;

typedef struct
{
//	uint8_t CANx;															//ָ���ĸ�CAN
	CAN_RxHeaderTypeDef rx_header;			//CAN ���ջ��������
	uint8_t             rx_data[1];				//�洢CAN�������� ����
}CAN_Rx_TypeDef;

void CAN_1_Filter_Config(void);
void CAN_2_Filter_Config(void);
void LK_MG4005_getInfo(Can_Export_Data_t RxMessage);
void DM_J8009_getInfo(DM_J8009_t *ptr, Can_Export_Data_t RxMessage);


void vTaskCanReceives( void const * argument);

#endif

