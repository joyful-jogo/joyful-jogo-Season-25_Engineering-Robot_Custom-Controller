#ifndef CHASSIS_CONTROL_H_
#define CHASSIS_CONTROL_H_





void Chassis_Processing(void);


#define M3508_LF_OPIDInit \
    {                        \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        30000.0f,              \
        30000.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }

#define M3508_RF_OPIDInit \
    {                        \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        30000.0f,              \
        30000.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
#define M3508_LB_OPIDInit \
    {                        \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        30000.0f,              \
        30000.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
#define M3508_RB_OPIDInit \
    {                        \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        30000.0f,              \
        30000.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
		
#endif
