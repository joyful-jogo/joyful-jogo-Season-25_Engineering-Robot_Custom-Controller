/**
  ******************************************************************************
  * @file    Wrist_swing.c
  * @author  
  * @version 
  * @date    
  * @brief  
  ******************************************************************************
  */
	
#include "Wrist_swing.h"
#include "DR16_Receiver.h"
#include "cmsis_os.h"
#include <stdlib.h>//abs
#include "Filter.h"
#include "Ramp.h"
#include "DRK_encoder.h"

LK_Motor_t LK_M;


#define Wrist_FULL_TRAVEL 360000
#define Wrist_HALF_TRAVEL 150000
#define Wrist_SPEED_NORMAL 18000

#define Wrist_ENCODER_MAX 65535
#define Wrist_FULL_SCALE_DEGREES 360.0f

float WristL_temp,WristL_slow_Inc = 0.34f;
float WristR_temp,WristR_slow_Inc = 0.34f;

float WristL_LpfAttFactor = 0.2f;
float WristR_LpfAttFactor = 0.2f;

void	Wrist_Motor_control(void)
{
	set_LK_MG4005_iqControl(1,LK_M.input_angleCule_L);//Ϊ�˽������ݱ����и�����
}


	
void Wrist_resetAngle(void)
{

}	
	
	

	void Wrist_Init(void)
{
	LK_M.input_angleCule_L = -24858;//����ʼλ�ã�0+��ʼֵ
//	LK_M.LK_MG[2].targetAngle = 0;//����ʼλ�ã�0+��ʼֵ
}
	


void Wrist_Processing(void)
{
//	if (DR16_data.rc.sw1 == 2&& DR16_data.rc.sw2 == 2)
//	{
//		LK_Motor_failure();
//	}
//	
//	
//	if (DR16_data.rc.sw1 == 1&& DR16_data.rc.sw2 == 3)
//	{
//LK_M.LK_MG[0].targetAngle += DR16_data.rc.ch1 *0.1;
//	}
//	
//LK_M.input_angleCule_L = LK_M.LK_MG[0].targetAngle;
	
//LK_M.input_angleCule_L = DRK_encoder[0].EncoderAngle *30;
//LK_M.input_angleCule_L = DRK_encoder[1].EncoderAngle *30;
//LK_M.input_angleCule_L = DRK_encoder[2].EncoderAngle *30;
	
Wrist_Motor_control();
}

void Wrist_limiting(void)
{
	if(LK_M.LK_MG[0].Real_encoder <= 10 || LK_M.LK_MG[0].Real_encoder >= 18526)
	{
		LK_M.input_angleCule_L = 0;
	}
		if(LK_M.LK_MG[0].Real_encoder <= 10 || LK_M.LK_MG[0].Real_encoder >= 18526)
	{
		LK_M.input_angleCule_L = 0;
	}
}



