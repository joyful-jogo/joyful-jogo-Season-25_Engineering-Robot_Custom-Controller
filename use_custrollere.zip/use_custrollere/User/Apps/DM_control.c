/**
  ******************************************************************************
  * @file    DMJ8009_control.c
  * @author  BLOCK
  * @version V1.0
  * @date    
  * @brief   ���������ƺ����ӿ�
  ******************************************************************************
  */
	
#include "DM_control.h"
#include "DR16_Receiver.h"
#include "Filter.h"
#include "Ramp.h"
#include "LK_MG4005_Motor.h"
#include "pid.h"


DM_Motor_t DM_M;

void DM_Motor_control(void)
{
MIT_CtrlMotor(&hcan1,0x01,  DM_M.input_pos_1,0,1.5, 0.1, 0);	  //vesΪ0������ģʽ44
MIT_CtrlMotor(&hcan1,0x02,  DM_M.input_pos_2,0,1.5, 0.1, 0);	 
//MIT_CtrlMotor(&hcan1,0x02,  0,0,1.5, 0.1, 0);	 

	
}

/**
  * @brief  ��е�۳�ʼ������
  * @param
  * @retval None
  */
void Arm_Init(void)
{
//DM_M.DM_J8009[0].targetAngle = DM_M.DM_J8009[0].position;
//DM_M.DM_J8009[1].targetAngle = DM_M.DM_J8009[1].position;
	
DM_M.DM_J8009[0].targetAngle = 0;
DM_M.DM_J8009[1].targetAngle = 0.9123;
}


uint8_t  DMkey_flag;

/**
  * @brief  ��е�����к���
  * @param  None
  * @retval None
  */
void Arm_Processing(void)
{
	
	if ((DR16_data.rc.sw1 == 2 && DR16_data.rc.sw2 == 2)
		 || DR16_data.offLineFlag == 1)
	{
		DM_Motor_failure();
		return;
		}
	else
	{
	  DM_Motor_enable();
	}

	if (DR16_data.rc.sw1 == 1 && DR16_data.rc.sw2 == 3)
	{
DM_M.DM_J8009[0].targetAngle += DR16_data.rc.ch2 *0.00007f; //0.000005f
DM_M.DM_J8009[1].targetAngle += DR16_data.rc.ch3 *0.00002f;
		
int test = 0;
		test += DR16_data.rc.ch3 *0.0004f;
		
//DM_M.input_pos_1 = DM_M.DM_J8009[0].targetAngle;
//VAL_LIMIT(DM_M.DM_J8009[0].targetAngle,-2,2);
		
DM_M.input_pos_2 = DM_M.DM_J8009[1].targetAngle;
//VAL_LIMIT(DM_M.DM_J8009[1].targetAngle,-12,12);
	}

DM_Motor_control();
	

}

//void Arm_zore(void)
//{
//			if (DR16_data.rc.sw1 == 1 && DR16_data.rc.sw2 == 1)
//	{
//		DM_Motor_save_zero_2();
//	}
//}



