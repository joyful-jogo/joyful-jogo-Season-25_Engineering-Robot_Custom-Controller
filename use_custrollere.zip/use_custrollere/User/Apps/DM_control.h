#ifndef __DM_CONTROL_H
#define __DM_CONTROL_H

#include "DM_J4310_Motor.h"
#include "pid.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cmsis_os.h"


typedef enum{
  DMJ4310_MODE_OFF = 0,
  DMJ4310_MODE_POSITION = 1,
  DMJ4310_MODE_MANUAL = 2,
	DMJ4310_MODE_LOCK = 3,
	DMJ4310_MODE_VISION = 4,	/*�Ӿ�����x,yȷ����ʯ���ĵ�ģʽ*/
}ArmMode_e;

/*̧��*/
typedef struct {
DM_J8009_t DM_J8009[2];
	
float input_pos_1,input_pos_2;
float input_vel_1,input_vel_2;
float input_torq_1,input_torq_2;
	
float Max_input_pos,Min_input_pos;
	

}DM_Motor_t;

extern DM_Motor_t DM_M;

void Arm_Init(void);
void Arm_Processing(void);
void Motor_control(void);
void Arm_zore(void);

//p5.0f
#define DM_J4310F_OPIDInit   \
    {                        \
        5.0f,              \
        0.0f,              \
        0.0f,              \
        100.0f,              \
        5.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
//p0.9 i0.1
#define DM_J4310F_IPIDInit   \
    {                        \
        0.9f,              \
        0.0f,              \
        0.0f,              \
        10.0f,              \
        8,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
#define DM_J4310B_OPIDInit   \
    {                        \
        1.0f,              \
        0.0f,              \
        0.0f,              \
        100.0f,              \
        100.0f,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }

#define DM_J4310B_IPIDInit   \
    {                        \
        0.9f,              \
        0.0f,              \
        0.0f,              \
        10.0f,              \
        100,              \
        0.0f,              \
        0.0f,              \
        {0.0f, 0.0f},      \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        0.0f,              \
        &pid_calc           \
    }
		
#endif
