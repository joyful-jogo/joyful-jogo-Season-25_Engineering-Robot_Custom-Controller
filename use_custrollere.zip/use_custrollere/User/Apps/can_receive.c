#include "can_receive.h"
#include "bsp_can.h"
#include "cmsis_os.h"
#include "DM_control.h"
#include "RM_control.h"
#include "Chassis_motor.h"
#include "DRK_encoder.h"



Can_Export_Data_t Can1_Export_Data;//�����洢���յ���CAN1����
Can_Export_Data_t Can2_Export_Data;//�����洢���յ���CAN2����


/**
  * @brief  ����CAN���յ�������
  */
void Process_CAN1_Message(Can_Export_Data_t *CanData)
{
    switch (CanData->CAN_RxHeader.StdId)
    {

				case 0x01:
				case 0x02:
				case 0x03:
             DRK_encoder_getInfo(*CanData);
				     break;	
			
//			
				case 0x10:
					   DM_J8009_getInfo(&DM_M.DM_J8009[0],*CanData); // Pass CanData directly
				     break;
				case 0x20:
					   DM_J8009_getInfo(&DM_M.DM_J8009[1],*CanData); // Pass CanData directly
				     break;
				
//
				case 0x140 + LK_MG4005_ID_1:
             LK_MG4005_getInfo(*CanData);
            break;
        case 0x140 + LK_MG4005_ID_2:
             LK_MG4005_getInfo(*CanData);
            break;
        case 0x140 + LK_MG8015_ID_3:
             LK_MG4005_getInfo(*CanData);
            break;
				
				case 0x205:
					  DJI_motor_getInfo(&GM6020_M.DJI_GM6020,*CanData);
				    break;
				case 0x207:
				case 0x208:
					{
            static uint8_t j = 0;
						j = CanData->CAN_RxHeader.StdId - 0x207;
            DJI_motor_getInfo(&M2006_M.DJI_M2006[j], *CanData);
						break;
					}        default:
            // Ignore unhandled IDs
            break;
    }
}

void Process_CAN2_Message(Can_Export_Data_t *CanData)
{
//		Motor_enable();

	    switch (CanData->CAN_RxHeader.StdId)
    {
//					case 0x20:
//				  DM_J8009_getInfo(&DM_M.DM_J8009[1],*CanData); // Pass CanData directly
//		   break;
				
        case 0x201:
        case 0x202:
        case 0x203:
        case 0x204:
            M3508_chassis_getInfo(*CanData); // Pass CanData directly
            break;
        default:
            // Ignore unhandled IDs
            break;
		}
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    Can_Export_Data_t *CanData;

    if (hcan->Instance == CAN1)
    {
        CanData = &Can1_Export_Data; // Use the correct data structure for CAN1
			  HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &CanData->CAN_RxHeader, CanData->CAN_RxMessage);
        Process_CAN1_Message(CanData);

    }
    else if (hcan->Instance == CAN2)
    {
        CanData = &Can2_Export_Data; // Use the correct data structure for CAN2
			  HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &CanData->CAN_RxHeader, CanData->CAN_RxMessage);
        Process_CAN2_Message(CanData); // Pass CanData directly
    }
    else
    {
        return; // Invalid CAN instance
    }

		
		
//    HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &CanData->CAN_RxHeader, CanData->CAN_RxMessage);
}






/**
 * @brief Task to receive and process CAN messages.
 */
void vTaskCanReceives(void const * argument)
{
    for (;;)
    {
        // ���CAN1 FIFO�Ƿ�����Ϣ
        if (HAL_CAN_GetRxFifoFillLevel(&hcan1, CAN_RX_FIFO0) > 0)
        {
            HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &Can1_Export_Data.CAN_RxHeader, Can1_Export_Data.CAN_RxMessage);
            Process_CAN1_Message(&Can1_Export_Data); // ����CAN1��Ϣ
        }

        // ���CAN2 FIFO�Ƿ�����Ϣ
        if (HAL_CAN_GetRxFifoFillLevel(&hcan2, CAN_RX_FIFO0) > 0)
        {
            HAL_CAN_GetRxMessage(&hcan2, CAN_RX_FIFO0, &Can2_Export_Data.CAN_RxHeader, Can2_Export_Data.CAN_RxMessage);
            Process_CAN2_Message(&Can2_Export_Data); // ����CAN2��Ϣ
        }

        vTaskDelay(10); // ��������ִ��Ƶ��
    }
}





