#include "send_to_referee.h"
#include "DRK_encoder.h"
#include "CRC8_CRC16.h"
#include "usart.h"  

Controller_t tx_data;


void Send_AllEncoders_CustomProtocol(DRK_encoder_t *encoder[6])
	{
    static uint8_t seq = 0;

    // ��� data ��
    for (int i = 0; i < DATA_LENGTH; i++)
        tx_data.data[i] = 0;
		
    // ÿ��������4�ֽڣ�ID + Angle_L + Angle_H + 0xFF
    for (int i = 0; i < 6; i++)
    {
        int offset = i * 4;
        uint16_t angle = encoder[i]->EncoderAngle;
        tx_data.data[offset + 0] = i + 1;              // ������ ID��1~6
        tx_data.data[offset + 1] = angle & 0xFF;       // Angle ��8λ
        tx_data.data[offset + 2] = (angle >> 8) & 0xFF;// Angle ��8λ
        tx_data.data[offset + 3] = 0xFF;               // �ָ���
    }
		
//        uint8_t angle_1 = encoder[0]->EncoderAngle;
//        tx_data.data[0] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[1] = angle_1 & 0xFF;       // Angle ��8λ
//        tx_data.data[2] = (angle_1 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[3] = 0xFF;               // �ָ���
//		
//        uint8_t angle_2 = encoder[1]->EncoderAngle;
//        tx_data.data[4] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[5] = angle_2 & 0xFF;       // Angle ��8λ
//        tx_data.data[6] = (angle_2 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[7] = 0xFF;               // �ָ���

//        uint8_t angle_3 = encoder[2]->EncoderAngle;
//        tx_data.data[8] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[9] = angle_3 & 0xFF;       // Angle ��8λ
//        tx_data.data[10] = (angle_3 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[11] = 0xFF;               // �ָ���
//				
//        uint8_t angle_4 = encoder[3]->EncoderAngle;
//        tx_data.data[12] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[13] = angle_4 & 0xFF;       // Angle ��8λ
//        tx_data.data[14] = (angle_4 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[15] = 0xFF;               // �ָ���
//				
//        uint8_t angle_5 = encoder[4]->EncoderAngle;
//        tx_data.data[16] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[17] = angle_5 & 0xFF;       // Angle ��8λ
//        tx_data.data[18] = (angle_5 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[19] = 0xFF;               // �ָ���
//				
//        uint8_t angle_6 = encoder[5]->EncoderAngle;
//        tx_data.data[20] = DRK_encoder_ID_1;              // ������ ID��1~6
//        tx_data.data[21] = angle_6 & 0xFF;       // Angle ��8λ
//        tx_data.data[22] = (angle_6 >> 8) & 0xFF;// Angle ��8λ
//        tx_data.data[23] = 0xFF;               // �ָ���
		
    // ����data[3~29] ���㣨����Ҫ��ɾ��
    for (int i = 24; i < DATA_LENGTH; i++)
        tx_data.data[i] = 0;

    // ���֡ͷ
    tx_data.frame_header.sof = 0xA5;
    tx_data.frame_header.data_length = DATA_LENGTH;  //30
    tx_data.frame_header.seq = seq++;

    // ����֡ͷCRC8
    append_CRC8_check_sum((uint8_t *)&tx_data.frame_header, FRAME_HEADER_LENGTH);

    // ������
    tx_data.cmd_id = CONTROLLER_CMD_ID;  // 0x0302

    // ��������CRC16
    append_CRC16_check_sum((uint8_t *)&tx_data, DATA_FRAME_LENGTH);

    // ���ڷ���
    HAL_UART_Transmit(&huart6, (uint8_t *)&tx_data, DATA_FRAME_LENGTH, 100);
}





